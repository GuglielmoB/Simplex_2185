#include "Player.h"

/*
namespace Simplex
{

	Player::Player()
	{
	}


	Player::~Player()
	{
	}

}
*/